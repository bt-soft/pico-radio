#ifndef __BEEPER_H__
#define __BEEPER_H__

class Beeper {

private:
    uint8_t beeperPin;

public:
    /**
     *
     */
    Beeper(uint8_t beeperPin) {
        this->beeperPin = beeperPin;
        pinMode(beeperPin, OUTPUT);
        digitalWrite(beeperPin, LOW);
    }

    /**
     *
     */
    void tick() {
        tone(beeperPin, 800);
        delay(10);
        noTone(beeperPin);
    }

    /**
     *
     */
    void error() {
        tone(beeperPin, 500);
        delay(100);
        tone(beeperPin, 500);
        delay(100);
        tone(beeperPin, 500);
        delay(100);
        noTone(beeperPin);
    }
};
#endif