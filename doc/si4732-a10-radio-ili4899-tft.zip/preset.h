#ifndef __PRESET_H__
#define __PRESET_H__

typedef struct // Group data
{
    const uint16_t groupIdx;
    const char *PresetName;
} Group;

typedef struct // Preset data
{
    const float memoryIdx;
    const char *MemoryName;
    const char *memoryGroup;
} Memory;

//======================================================= Presets Groups    ================================
Group group[] PROGMEM = {
    733, "MILANO",  //
    737, "ROMA",    //
    762, "FIRENZE", //
    769, "MODENA",  //
    771, "VENEZIA", //
    776, "BOLOGNA", //
    777, "FERRARA", //
    778, "PADOVA",  //
};
//======================================================= END Presets Groups     ===========================

//======================================================= Memory     =======================================
Memory memory[] PROGMEM = {

    87.5, "R.CAPITAL", "777",    //
    27125, "CB 14 Chan.", "ALL", //
};
//======================================================= END Memory     ===================================
#endif // __PRESET_H__